package com.film_api.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.film_api.models.Film;
import com.film_api.dao.FilmDAO;
import com.film_api.utils.FilmUtils;

/**
 * Servlet implementation class FilmsServlet
 */
@WebServlet("/api/films")
public class FilmsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmDAO filmDAO = new FilmDAO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FilmsServlet() {
		super();
	}

	/**
	 * GET /films
	 *
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Check user preference for XML, JSON or TEXT
		String accept = request.getHeader("accept");

		List<Film> films = filmDAO.getAllFilms();

		String payload = convertToAcceptedType(films, accept);

		response.setStatus(HttpServletResponse.SC_OK);
		response.setContentType(accept != null ? accept : "application/json");
		response.getWriter().print(payload);
	}

	/**
	 * POST /films
	 *
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Film film = covertFromContentType(request);

		if (film == null) {
			// Invalid film data.
			badRequestResponse(response);
		} else {
			// Add film to the database.
			filmDAO.addFilm(film);
			sendResponse(request, response, film, HttpServletResponse.SC_CREATED);
		}
	}

	/**
	 * PUT /films
	 *
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Film film = covertFromContentType(request);

		if (film == null) {
			// Invalid film data.
			badRequestResponse(response);
		} else {
			// Update the film
			filmDAO.updateFilm(film);
			sendResponse(request, response, film, HttpServletResponse.SC_ACCEPTED);
		}

	}

	/**
	 * DELETE /films?id
	 *
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getQueryString());

		// Delete film with the id
		filmDAO.deleteFilm(id);

		String accept = request.getHeader("accept");

		response.setStatus(HttpServletResponse.SC_OK);
		response.setContentType(accept != null ? accept : "text/plain");
	}

	/**
	 * Parses a POST or PUT request body.
	 * 
	 * @param request The request to parse its body.
	 * @return String of the parsed body.
	 * @throws ServletException
	 * @throws IOException
	 */
	private String parseRequestBody(HttpServletRequest request) throws ServletException, IOException {
		Stream<String> reader = request.getReader().lines();
		String body = "";

		for (String line : reader.toList()) {
			body = body.concat(line.strip());
		}

		return body;
	}

	/**
	 * Converts film to the accepted mime type. Works with JSON, XML and TEXT
	 * formats. If another format is passed, or none is given, JSON is returned by
	 * default.
	 * 
	 * @param film   The film to convert.
	 * @param accept Value of the Accept header from the request.
	 * @return A string of the film in the accepted mime type.
	 */
	private String convertToAcceptedType(Film film, String accept) {

		String filmString = FilmUtils.toJSON(film); // Default return is json

		if (accept == null || accept.contains("json")) {
			// Pass. filmString already assigned to JSON
		} else if (accept.contains("xml")) {
			filmString = FilmUtils.toXML(film);
		} else if (accept.contains("plain")) {
			filmString = FilmUtils.toString(film);
		}

		return filmString;
	}

	/**
	 * Converts list of films to the accepted mime type. Works with JSON, XML and
	 * TEXT formats. If another format is passed, or none is given, JSON is returned
	 * by default.
	 * 
	 * @param films  List of films to convert.
	 * @param accept Value of the Accept header from the request.
	 * @return A string of the film in the accepted mime type.
	 */
	private String convertToAcceptedType(List<Film> films, String accept) {

		String filmString = FilmUtils.toJSON(films); // Default return is json

		if (accept == null || accept.contains("json")) {
			// Pass. filmString already assigned to JSON
		} else if (accept.contains("xml")) {
			filmString = FilmUtils.toXML(films);
		} else if (accept.contains("plain")) {
			filmString = FilmUtils.toString(films, true);
		}

		return filmString;
	}

	/**
	 * Converts film data in the request body from the ContentType format to a Fim
	 * object. Supported formats are JSON and XML.
	 * 
	 * @param request HTTP request with the film data in the body.
	 * @return Film with the values from the request body.
	 * @throws ServletException
	 * @throws IOException
	 */
	private Film covertFromContentType(HttpServletRequest request) throws ServletException, IOException {
		Film film = null;

		String body = parseRequestBody(request);
		String contentType = request.getContentType();

		if (contentType != null && contentType.contains("json")) {
			film = FilmUtils.fromJSON(body);
		} else if (contentType != null && contentType.contains("xml")) {
			film = FilmUtils.fromXML(body);
		} else if (contentType != null && contentType.contains("plain")) {
			film = FilmUtils.fromString(body);
		}

		return film;
	}

	/**
	 * Sends response for POST and PUT requests.
	 * 
	 * @param request    The HTTP request.
	 * @param response   The HTTP response.
	 * @param film       The film to return in the response.
	 * @param statusCode Status code of the HTTP call.
	 * @throws IOException
	 */
	private void sendResponse(HttpServletRequest request, HttpServletResponse response, Film film, int statusCode)
			throws IOException {
		String accept = request.getHeader("accept"); // get Accept Heaser
		String acceptedFilm = convertToAcceptedType(film, accept);

		response.setStatus(statusCode);
		response.setContentType(accept != null ? accept : "application/json");
		response.getWriter().print(acceptedFilm);
	}

	/**
	 * Sends a bad request response when the film data provided in the body is
	 * invalid or does not match the Content-Type header.
	 * 
	 * @param response The HTTP response.
	 * @throws IOException
	 */
	private void badRequestResponse(HttpServletResponse response) throws IOException {
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		response.setContentType("application/json");
		response.getWriter().print(
				"{\"detail\": \"Invalid film data. Check if data format matches Content-Type or if the data has errors\"}");
	}
}

package com.film_api.dao;

public class Main {
	public static void main(String[]args) {
		FilmDAO fm = new FilmDAO();
		//System.out.println(fm.getAllFilms());
		System.out.println(fm.getFilmByID(10001));
	}
}

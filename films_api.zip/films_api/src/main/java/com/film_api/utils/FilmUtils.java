package com.film_api.utils;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.film_api.models.Film;

/**
 * Utility class for handling Film Object Serialization and deserialization from
 * XML, JSON or TEXT.
 */
public final class FilmUtils {

	private FilmUtils() {
		// Private constructor to prevent instantiation
	}

	/**
	 * Converts a film into a single string
	 * 
	 * @param film Film to convert.
	 * @return String representation if the film.
	 */
	public static String toString(Film film) {
		return film.toString();
	}

	/**
	 * Coverts a list of films into a single string.
	 * 
	 * @param films   List of films.
	 * @param newline Set to true to add newline after every film.
	 * @return String representation of the films.
	 */
	public static String toString(List<Film> films, boolean newline) {
		List<String> filmStrings = new ArrayList<String>();

		for (Film film : films) {
			filmStrings.add(newline ? "\n" + film.toString() : film.toString());
		}

		if (newline)
			filmStrings.add("\n");

		return filmStrings.toString();
	}

	/**
	 * Decodes a TEXT body into a Film object.
	 * 
	 * @param textString The text string to decode.
	 * @return The decoded film from the textString.
	 *
	 *         <h3>Format:</h3> The different properties of the film must be
	 *         separated by a comma with the property and values separated by an
	 *         equal sign.
	 * 
	 *         <h4>Example:</h4>
	 *         <li>Default Film String</li> Film [id=1, title=Nobody, year=2020,
	 *         director=Luke Smith, stars=Somebody, review=Great Movie]
	 *         <li>Comma separated String</li> id=1, title=Nobody, year=2020,
	 *         director=Luke Smith, stars=Somebody, review=Great Movie
	 *         <p>
	 * 
	 * @implNote If multiple commas are encountered, eg if a title has a comma, then
	 *           only the first part of the property before the comma is used.
	 *           Support for a property with a comma separated value will be added
	 *           soon.
	 *
	 *           <p>
	 *           EG. <b>title=Nobody, One, year=2020</b> -> would only assign Nobody
	 *           to title and One would be discarded.
	 */
	public static Film fromString(String textString) {
		if (textString.startsWith("Film [")) {
			// Remove 'Film [' prefix.
			textString = textString.substring("Film [".length());
			// Remove trailin ']'
			textString = textString.replaceFirst("]$", "");
		}
		HashMap<String, String> data = new HashMap<String, String>();

		// comma is the delimeter for the properties
		String[] splitTextString = textString.split(",");

		for (String str : splitTextString) {
			// Split at = to get key and value. (key=value)
			String[] keyAndValue = str.split("=");

			if (keyAndValue.length > 1) {
				data.put(keyAndValue[0].strip(), keyAndValue[1].strip());
			}

			/**
			 * TODO: Append values without key to the previous key. E.G. title=Nobody, One,
			 * year=2020 => Film.title = "Nobody, One"
			 */
		}

		Film film = new Film(data);

		return film;
	}

	/**
	 * Encodes list of films into a XML string.
	 * 
	 * @param films List of films to encode.
	 * @return XML string representation of the films.
	 */
	public static String toXML(List<Film> films) {
		String xml = null;
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			XMLEncoder encoder = new XMLEncoder(out);
			encoder.writeObject(films);
			encoder.close();
			xml = out.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return xml;
	}

	/**
	 * Encodes a film into a XML string.
	 * 
	 * @param film The film to encode.
	 * @return XML string representation of the film.
	 */
	public static String toXML(Film film) {
		String xml = null;
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			XMLEncoder encoder = new XMLEncoder(out);
			encoder.writeObject(film);
			encoder.close();
			xml = out.toString();
		} catch (Exception e) {
		}
		return xml;
	}

	/**
	 * Decodes xml string into Film object.
	 * 
	 * @param xmlString The xml sring to decode.
	 * @return The decoded film from the xmlString, or null.
	 */
	@SuppressWarnings("unchecked")
	public static Film fromXML(String xmlString) {

		try (XMLDecoder decoder = new XMLDecoder(new ByteArrayInputStream(xmlString.getBytes()))) {
			Object object = decoder.readObject();

			if (object instanceof ArrayList) {
				ArrayList<Film> filmList = (ArrayList<Film>) object;

				// Return only one film object.
				// TODO: Handle multiple films.
				return filmList.size() > 0 ? filmList.get(0) : null;
			} else {
				return (Film) object;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Encodes a list of films to a JSON string.
	 * 
	 * @param films List of films to encode.
	 * @return JSON string of the films.
	 */
	public static String toJSON(List<Film> films) {
		try {
			JSONArray jsonArr = new JSONArray(films);
			return jsonArr.toString(2); // 2 is indentation level
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Encodes a film to a JSON string
	 * 
	 * @param film The film to encode.
	 * @return JSON string of the encoded film.
	 */
	public static String toJSON(Film film) {
		try {
			JSONObject jsonObj = new JSONObject(film);
			return jsonObj.toString(2); // 2 is indentation level
		} catch (JSONException e) {
		}
		return null;
	}

	/**
	 * Decodes a json String into a Film object.
	 * 
	 * @param jsonString The json string to decode.
	 * @return Film instantiated with the decoded json string, or null.
	 */
	public static Film fromJSON(String jsonString) {
		try {
			JSONObject jsonObj = new JSONObject(jsonString);

			// Instantiate film from the jsonObj
			Film film = new Film(jsonObj);
			return film;
		} catch (JSONException e) {
			try {
				JSONArray jsonArray = new JSONArray(jsonString);

				// Create only one film.
				// TODO: Handle multiple films at once.
				Film film = new Film(jsonArray.getJSONObject(0));
				return film;
			} catch (JSONException ne) {
				return null;
			}
		}
	}
}

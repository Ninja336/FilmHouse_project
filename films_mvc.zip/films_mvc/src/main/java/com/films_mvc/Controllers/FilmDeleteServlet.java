package com.films_mvc.Controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.films_mvc.Models.DAO.FilmDAO;

/**
 * Servlet implementation class FilmDeleteServlet
 */
@WebServlet("/FilmDelete")
public class FilmDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmDAO filmDAO = new FilmDAO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FilmDeleteServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Id of the film to delete
		int id = Integer.parseInt(request.getParameter("id"));

		// Delete the film
		filmDAO.deleteFilm(id);

		response.sendRedirect("films");
	}

}

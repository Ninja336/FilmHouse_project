package com.films_mvc.Controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.films_mvc.Models.Film;
import com.films_mvc.Models.DAO.FilmDAO;

/**
 * Servlet implementation class FilmInsertServlet
 */
@WebServlet("/FilmInsert")
public class FilmInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmDAO filmDAO = new FilmDAO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FilmInsertServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("FilmFormPage.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String title = request.getParameter("title");
		int year = Integer.parseInt(request.getParameter("year"));
		String director = request.getParameter("director");
		String stars = request.getParameter("stars");
		String review = request.getParameter("review");

		Film newFilm = new Film();
		newFilm.setTitle(title);
		newFilm.setYear(year);
		newFilm.setDirector(director);
		newFilm.setStars(stars);
		newFilm.setReview(review);
		filmDAO.addFilm(newFilm);
		response.sendRedirect("films");
	}

}

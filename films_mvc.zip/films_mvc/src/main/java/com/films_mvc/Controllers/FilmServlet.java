package com.films_mvc.Controllers;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.films_mvc.Models.Film;
import com.films_mvc.Models.DAO.FilmDAO;

import java.io.IOException;
import java.util.List;

@WebServlet("/films")
public class FilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmDAO filmDAO = new FilmDAO();

	/**
	 * Get films.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Films from the database
		List<Film> films = filmDAO.getAllFilms();

		request.setAttribute("films", films);

		// Whether the request is from search tab
		String search = request.getParameter("search");

		if (search != null) {
			// Search Tab
			request.getRequestDispatcher("FilmsSearch.jsp").forward(request, response);
		} else {
			request.getRequestDispatcher("films.jsp").forward(request, response);
		}

	}
}

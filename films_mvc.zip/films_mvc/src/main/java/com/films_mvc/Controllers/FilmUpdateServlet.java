package com.films_mvc.Controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.films_mvc.Models.Film;
import com.films_mvc.Models.DAO.FilmDAO;

/**
 * Servlet implementation class FilmUpdateServlet
 */
@WebServlet("/FilmUpdate")
public class FilmUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmDAO filmDAO = new FilmDAO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FilmUpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Retrieve parameters from the body
		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		int year = Integer.parseInt(request.getParameter("year"));
		String director = request.getParameter("director");
		String stars = request.getParameter("stars");
		String review = request.getParameter("review");

		Film updatedFilm = new Film();
		updatedFilm.setId(id);
		updatedFilm.setTitle(title);
		updatedFilm.setYear(year);
		updatedFilm.setDirector(director);
		updatedFilm.setStars(stars);
		updatedFilm.setReview(review);

		// Update film
		filmDAO.updateFilm(updatedFilm);

		response.sendRedirect("films");
	}

}

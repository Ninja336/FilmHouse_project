package com.films_mvc.Filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import com.films_mvc.utils.HttpMethodRequestWrapper;

/**
 * Servlet Filter implementation class HttpMethodOverrideFilter.
 * 
 * Checks for the existence of `_method` parameter that overrides the method
 * used by the request.
 * 
 * Mostly converts POST to either PUT or DELETE so that they can be handled by
 * the correct servlet.
 */
@WebFilter("/*")
public class HttpMethodOverrideFilter extends HttpFilter implements Filter {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpFilter#HttpFilter()
	 */
	public HttpMethodOverrideFilter() {
		super();
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		// Check if "_method" parameter exists in the request
		String methodOverride = request.getParameter("_method");

		if (methodOverride != null && !methodOverride.isEmpty()) {
			String newMethod = methodOverride.toUpperCase();
			HttpServletRequestWrapper requestWrapper = new HttpMethodRequestWrapper(req, newMethod);

			// Proceed with new request with updated method
			chain.doFilter(requestWrapper, res);
		} else {
			// No method override, proceed with the original request
			chain.doFilter(request, response);
		}
	}
}

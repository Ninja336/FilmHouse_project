package com.films_mvc.Models.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.films_mvc.Models.Film;

public class FilmDAO {
	Film oneFilm = null;
	Connection conn = null;
	Statement stmt = null;
	String user = "root";
	String password = "airbus@380";
	// Note none default port used, 6306 not 3306
	 //String url = "jdbc:mysql://localhost:3306/film";
	 String url = "jdbc:mysql://localhost:3306/film?serverTimezone=UTC";


	public FilmDAO() {
	}

	/**
	 * Opens a connection to the MYSQL database.
	 */
	private void openConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			System.out.println(e);
		}

		// connecting to database
		try {
			conn = DriverManager.getConnection(url, user, password);
			stmt = conn.createStatement();
		} catch (SQLException se) {
			System.out.println(se);
		}
	}

	/**
	 * Closes MYSQL database connection.
	 */
	private void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Adds a film to the database.
	 * 
	 * @param film Film to add to the database.
	 */
	public void addFilm(Film film) {
		openConnection();
		try {
			String insertSQL = "INSERT INTO films (title, year, director, stars, review) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
			preparedStatement.setString(1, film.getTitle());
			preparedStatement.setInt(2, film.getYear());
			preparedStatement.setString(3, film.getDirector());
			preparedStatement.setString(4, film.getStars());
			preparedStatement.setString(5, film.getReview());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException se) {
			System.out.println(se);
		}
		closeConnection();
	}

	/**
	 * Updates a film in the database.
	 *
	 * @param film Film to update.
	 */
	public void updateFilm(Film film) {
		openConnection();
		try {
			String updateSQL = "UPDATE films SET title=?, year=?, director=?, stars=?, review=? WHERE id=?";
			PreparedStatement preparedStatement = conn.prepareStatement(updateSQL);
			preparedStatement.setString(1, film.getTitle());
			preparedStatement.setInt(2, film.getYear());
			preparedStatement.setString(3, film.getDirector());
			preparedStatement.setString(4, film.getStars());
			preparedStatement.setString(5, film.getReview());
			preparedStatement.setInt(6, film.getId());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException se) {
			System.out.println(se);
		}
		closeConnection();
	}

	/**
	 * Deletes a film with the given id from the database.
	 *
	 * @param id Id of the film to delete.
	 */
	public void deleteFilm(int id) {
		openConnection();
		try {
			String deleteSQL = "DELETE FROM films WHERE id=?";
			PreparedStatement preparedStatement = conn.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException se) {
			System.out.println(se);
		}
		closeConnection();
	}

	/**
	 * Gets next film in a ResultSet.
	 *
	 * @param rs SQL ResultSet to operate on.
	 * @return The next film in the rs.
	 */
	private Film getNextFilm(ResultSet rs) {
		Film thisFilm = null;
		try {
			thisFilm = new Film(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("director"),
					rs.getString("stars"), rs.getString("review"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return thisFilm;
	}

	/**
	 * Retrieves all films from the database.
	 *
	 * @return An array of the films.
	 */
	public ArrayList<Film> getAllFilms() {

		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();

		try {
			String selectSQL = "select * from films";
			ResultSet rs1 = stmt.executeQuery(selectSQL);
			// Retrieve the results
			while (rs1.next()) {
				oneFilm = getNextFilm(rs1);
				allFilms.add(oneFilm);
			}

			stmt.close();
			closeConnection();
		} catch (SQLException se) {
			System.out.println(se);
		}

		return allFilms;
	}

	/**
	 * Retrieves a film from the database using the given id.
	 *
	 * @param id Id of the film to get.
	 * @return A film with the given id if it exists, else null.
	 */
	public Film getFilmByID(int id) {

		openConnection();
		oneFilm = null;
		// Create select statement and execute it
		try {
			String selectSQL = "select * from films where id=" + id;
			ResultSet rs1 = stmt.executeQuery(selectSQL);
			// Retrieve the results
			while (rs1.next()) {
				oneFilm = getNextFilm(rs1);
			}

			stmt.close();
			closeConnection();
		} catch (SQLException se) {
			System.out.println(se);
		}

		return oneFilm;
	}
}

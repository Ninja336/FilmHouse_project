/**
 * 
 */
package com.films_mvc.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * Overrides the default getmethod() function of the HTTPServletRequestWrapper
 * so that the method used at instantiation is returned instead.
 */
public class HttpMethodRequestWrapper extends HttpServletRequestWrapper {
	private final String method;

	public HttpMethodRequestWrapper(HttpServletRequest request, String method) {
		super(request);
		this.method = method;
	}

	@Override
	public String getMethod() {
		return method;
	}
}
